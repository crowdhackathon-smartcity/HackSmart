package kk;

import kk.model.MonumentRepository;
import kk.model.entities.Monument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

	private static final Logger log = LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) {
		SpringApplication.run(Application.class);
	}

	@Bean
	public CommandLineRunner loadData(MonumentRepository repository) {
		return (args) -> {
			// save a couple of customers
//			repository.save(new Monument("Jack", "Bauer",null,"test","test","linktest","tag3"));
//			repository.save(new Monument("Chloe", "O'Brian",null,"test","test","linktest","tag3"));
//			repository.save(new Monument("Chloe", "O'Brian",null,"test","test","linktest","tag3"));
//			repository.save(new Monument("Chloe", "O'Brian",null,"test","test","linktest","tag3"));
//			repository.save(new Monument("Chloe", "O'Brian",null,"test","test","linktest","tag3"));
//			repository.save(new Monument("Chloe", "O'Brian",null,"test","test","linktest","tag3"));
//





		};
	}

}
