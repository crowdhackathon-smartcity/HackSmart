package kk.view;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FileResource;
import com.vaadin.server.Sizeable;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.*;
import com.vaadin.ui.Button.ClickEvent;

import kk.model.MonumentRepository;
import kk.model.entities.Monument;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


/**
 * Created by kechagiaskonstantinos on 13/05/2017.
 */
@SpringView(name = UIUpload.VIEW_NAME)
public class UIUpload extends VerticalLayout implements View{

    public static final String VIEW_NAME = "UIUpload";

    @Autowired
    MonumentRepository repository;

    Grid upLoadGrid;

    Button saveButton;

    TextField nameTextField;
    TextField descrTextField;
    TextField longtitudeTextField;
    TextField latitudeTextField;
    TextField linkTextField;
    TextField tagTextField;
    byte[] data;
    Upload upload;

    String pathFile;
    
    private GoogleMap googleMap;
    private GoogleMapMarker kakolaMarker = new GoogleMapMarker(
            "DRAGGABLE: Kakolan vankila", new LatLon(60.44291, 22.242415),
            true, null);

    public UIUpload(){
        HorizontalSplitPanel horizontalSplitPanel = new HorizontalSplitPanel();
        horizontalSplitPanel.setSplitPosition(75, Sizeable.UNITS_PERCENTAGE);
        VerticalLayout verticalLayout = new VerticalLayout();
        nameTextField = new TextField("Name");
        descrTextField = new TextField("Description");
        //
        //Show uploaded file in this placeholder
        final Image image = new Image("Uploaded Image");

        // Implement both receiver that saves upload in a file and
        // listener for successful upload
        class ImageUploader implements Upload.Receiver, Upload.SucceededListener {
            public File file;

            public OutputStream receiveUpload(String filename,
                                              String mimeType) {
                FileOutputStream fos = null; // Output stream to write to
                pathFile = "/Users/kechagiaskonstantinos/Desktop/Uploads" + filename;
                file = new File(pathFile);
                try {
                    // Open the file for writing.
                    fos = new FileOutputStream(file);
                } catch (final java.io.FileNotFoundException e) {
                    // Error while opening the file. Not reported here.
                    e.printStackTrace();
                    return null;
                }
                return fos; // Return the output stream to write to

            }

            public void uploadSucceeded(Upload.SucceededEvent event) {
                // Show the uploaded file in the image viewer
                image.setSource(new FileResource(file));
                Path path = Paths.get(pathFile);
                data = null;
                try {
                    data = Files.readAllBytes(path);
                    file.delete();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        ImageUploader receiver = new ImageUploader();

        // Create the upload with a caption and set receiver later
        upload = new Upload("Upload Image Here", receiver);
        upload.setImmediateMode(false);
        upload.addSucceededListener(receiver);
        //
        longtitudeTextField = new TextField("Longtitude");
        latitudeTextField = new TextField("Latitude");
        linkTextField = new TextField("Link");
        tagTextField = new TextField("Tag");

        verticalLayout.addComponent(nameTextField);
        verticalLayout.addComponent(descrTextField);
        verticalLayout.addComponent(upload);
        verticalLayout.addComponent(longtitudeTextField);
        verticalLayout.addComponent(latitudeTextField);
        verticalLayout.addComponent(linkTextField);
        verticalLayout.addComponent(tagTextField);
        saveButton = new Button("Save");
        verticalLayout.addComponent(saveButton);

        googleMap = new GoogleMap(null, null, null);
        googleMap.setCenter(new LatLon(60.440963, 22.25122));
        googleMap.setZoom(10);
        googleMap.setSizeFull();
        kakolaMarker.setAnimationEnabled(false);
        googleMap.addMarker(kakolaMarker);
        horizontalSplitPanel.setFirstComponent(googleMap);

        horizontalSplitPanel.setSecondComponent(verticalLayout);
        horizontalSplitPanel.setSizeFull();

        setSizeFull();
        addComponent(horizontalSplitPanel);
    }

    @PostConstruct
    void init() {
        saveButton.addClickListener((e)->this.savePressed(e));
    }
    
    private void savePressed(ClickEvent e) {
    	repository.save(new Monument(nameTextField.getValue(), descrTextField.getValue(),data, longtitudeTextField.getValue(), latitudeTextField.getValue(), linkTextField.getValue(),tagTextField.getValue()));
		Notification.show("Saved in DB");
		nameTextField.setValue("");
		descrTextField.setValue("");
		longtitudeTextField.setValue("");
		latitudeTextField.setValue("");
		linkTextField.setValue("");
        tagTextField.setValue("");

    	return;
	}


    @Override
    public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {

    }
}
