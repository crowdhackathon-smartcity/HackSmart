package kk.view;

import com.vaadin.navigator.Navigator;
import com.vaadin.spring.navigator.SpringViewProvider;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import kk.model.MonumentRepository;
import kk.model.entities.Monument;
import kk.utils.dijkstra.Algorithm.Dijkstra;
import kk.utils.dijkstra.model.Edge;
import kk.utils.dijkstra.model.Graph;
import kk.utils.dijkstra.model.Vertex;
import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.server.FontAwesome;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.Button;
import com.vaadin.ui.UI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

@SpringUI
public class VaadinUI extends UI {

	@Autowired
	private SpringViewProvider viewProvider;

	@Autowired
	MonumentRepository monumentRepository;

	@Override
	protected void init(VaadinRequest request) {
		getPage().setTitle("Smartacous");

		initDijkstra();

		final VerticalLayout root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.setSpacing(true);
		setContent(root);

		final Panel viewContainer = new Panel();
		viewContainer.setSizeFull();
		root.addComponent(viewContainer);
		root.setExpandRatio(viewContainer, 1.0f);

		// Create a navigator to control the views
		setNavigator(new Navigator(this, viewContainer));
		getNavigator().addProvider(viewProvider);


		// Create and register the views
		getNavigator().addView("UIUpload", new UIUpload());
		getNavigator().navigateTo("UIUpload");

	}

	private void initDijkstra() {
		List<Monument> monumentList = monumentRepository.findAll();

		List<Vertex> nodes = new ArrayList<Vertex>();
		List<Edge> edges = new ArrayList<Edge>();

		HashMap<String,ArrayList<Monument>> tagHashMap = new HashMap<String,ArrayList<Monument>>();
		for(Monument monument :monumentList){
			if(monument.getTag() == null)
				continue;
			if(tagHashMap.containsKey(monument.getTag())){
				tagHashMap.get(monument.getTag()).add(monument);
			}else{
				tagHashMap.put(monument.getTag(),new ArrayList<Monument>());
			}
		}

		for(ArrayList<Monument> monumentArrayList :tagHashMap.values()){
			for(Monument monument : monumentArrayList){
				nodes.add(new Vertex(monument.getId().toString(),monument.getTag()));
				System.out.println("ID : " + monument.getId() + " , tag : " + monument.getTag());
			}
		}
		for(Vertex nodesVertex : nodes) {
			for (Vertex destNodesVertex : nodes){
				if (nodes.equals(destNodesVertex))
					continue;
				if(nodesVertex.getName().equals(destNodesVertex.getName())){
					int duration = -1;
					duration = Math.abs(Integer.valueOf(nodesVertex.getName().substring(3)) - Integer.valueOf(destNodesVertex.getName().substring(3)));
					if(duration != -1)
						addLane(edges,"From : " + nodesVertex.getId() + "To : " + destNodesVertex.getId(),nodesVertex,destNodesVertex,duration);
				}

			}
		}

		Graph graph = new Graph(nodes, edges);
		Dijkstra dijkstra = new Dijkstra(graph);
		dijkstra.execute(nodes.get(0));
		LinkedList<Vertex> path = dijkstra.getPath(nodes.get(10));

		for (Vertex vertex : path) {
			System.out.println(vertex);
		}
	}

	private void addLane(List<Edge> edges,String laneId, Vertex sourceLoc, Vertex destLoc,
						 int duration) {
		Edge lane = new Edge(laneId,sourceLoc, destLoc, duration );
		edges.add(lane);
	}

}
