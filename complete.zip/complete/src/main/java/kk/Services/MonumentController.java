package kk.Services;

import com.google.cloud.vision.spi.v1.ImageAnnotatorClient;
import com.google.cloud.vision.v1.*;
import com.google.protobuf.ByteString;
import info.bliki.api.Connector;
import info.bliki.api.Page;
import info.bliki.api.PageInfo;
import info.bliki.api.User;
import kk.model.MonumentRepository;
import kk.model.entities.Monument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.management.MonitorInfo;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by kechagiaskonstantinos on 13/05/2017.
 */
@RestController
public class MonumentController {

    @Autowired
    MonumentRepository monumentRepository;

    @RequestMapping("/saveMonument")
    public Monument saveMonumen(@RequestParam(value="name") String name,@RequestParam(value="img") String img,@RequestParam(value="longtitude") String longtitude,@RequestParam(value="latitude") String latitude) {
        byte[] imgB = img.getBytes();
        Monument monument = new Monument(name,null,imgB,longtitude,latitude,null,null);
        monumentRepository.save(monument);
        return monument;
    }

    @RequestMapping("/searchMonument")
    public List<Monument> searchMonument(@RequestParam(value="startTime") String startTime,@RequestParam(value="duration") String duration, @RequestParam(value="longtitude") String longtitude, @RequestParam(value="latitude") String latitude) {
        List<Monument> monumentList = new ArrayList<Monument>();
        monumentList.add(new Monument("aaaaa",null,null,longtitude,latitude,null,null));
        monumentList.add(new Monument("aaaaa",null,null,longtitude,latitude,null,null));
        monumentList.add(new Monument("aaaaa",null,null,longtitude,latitude,null,null));
        return monumentList;
    }

    @RequestMapping("/getMonumentDetails")
    public String getMonumentDetails(@RequestParam(value="name") String name) {
//        String[] listOfTitleStrings = { "Main Page", "API" };
//        User user = new User("", "", "https://meta.wikimedia.org/w/api.php");
//        user.login();
//        List<Page> listOfPages = user.queryCategories(listOfTitleStrings);
//        for (Page page : listOfPages) {
//            // print page information
//            System.out.println(page.toString());
//            for (int j = 0; j < page.sizeOfCategoryList(); j++) {
//                PageInfo cat = page.getCategory(j);
//                // print every category in this page
//                System.out.println(cat.toString());
//            }
//        }

        String pageName = "File:Parthenon.jpg";
        User user = new User("", "", "https://en.wikipedia.org/w/api.php");
        Connector connector = new Connector();
        user = connector.login(user);

        System.out.println("PAGE-NAME: " + pageName);
        // set image width thumb size to 200px
        List<Page> pages = user.queryImageinfo(new String[] { pageName }, 200);

        System.out.println("PAGES: " + pages.get(0).getTitle());

        if (pages != null) {
            System.out.println("PAGES: " + pages.size());

        } else {
            System.out.println("PAGES: NULL!");
        }

        String imgLink = null;
        for (Page page : pages) {
            imgLink = page.getImageUrl();
            System.out.println("IMG-THUMB-URL: " + page.getImageThumbUrl());
            System.out.println("IMG-URL: " + page.getImageUrl());
        }
        return imgLink;
    }

    @RequestMapping("/getMonumentNameFromImage")
    public String getMonumentNameFromImage(@RequestParam(value="img") String img,@RequestParam(value="longtitude") String longtitude,@RequestParam(value="latitude") String latitude) {
        byte[] imgB = img.getBytes();
        String descr = getDescriptionFromGoogleAPI(imgB);
        return descr;
    }

    private String getDescriptionFromGoogleAPI(byte[] imgB) {
        List<AnnotateImageRequest> requests = new ArrayList<>();

        ByteString imgBytes = ByteString.copyFrom(imgB);

        Image img = Image.newBuilder().setContent(imgBytes).build();
        Feature feat = Feature.newBuilder().setType(Feature.Type.LANDMARK_DETECTION).build();
        AnnotateImageRequest request =
                AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
        requests.add(request);

        BatchAnnotateImagesResponse response =
                null;
        try {
            response = ImageAnnotatorClient.create().batchAnnotateImages(requests);
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<AnnotateImageResponse> responses = response.getResponsesList();

        for (AnnotateImageResponse res : responses) {
            if (res.hasError()) {
                System.out.printf("Error: %s\n", res.getError().getMessage());
                return "Error";
            }

            // For full list of available annotations, see http://g.co/cloud/vision/docs
            for (EntityAnnotation annotation : res.getLandmarkAnnotationsList()) {
                LocationInfo info = annotation.getLocationsList().listIterator().next();
                System.out.printf("Landmark: %s\n %s\n", annotation.getDescription(), info.getLatLng());
            }
        }
        //Mock up just because google Vision API is paid
        return "Akropolis";
    }


}
