package kk.model.entities;

import org.springframework.stereotype.Component;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;

@Component
@Entity
public class Monument {

	@Id
	@GeneratedValue
	private Long id;

	private String name;

	private String description;

	@Lob
	private byte[] blob;

	private String longitude;

	private String latitude;

	private String linkToWiki;

	private String tag;

	public Monument() {
	}

	public Monument(String name, String description,byte[] img, String longitude, String latitude,String linkToWiki,String tag) {
		this.name = name;
		this.description = description;
		this.blob = img;
		this.longitude = longitude;
		this.latitude = latitude;
		this.linkToWiki = linkToWiki;
		this.tag = tag;
	}


	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getLongitude() {
		return longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public Long getId() {

		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLinkToWiki() {
		return linkToWiki;
	}

	public void setLinkToWiki(String linkToWiki) {
		this.linkToWiki = linkToWiki;
	}

	public byte[] getBlob() {
		return blob;
	}

	public void setBlob(byte[] blob) {
		this.blob = blob;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	@Override
	public String toString() {
		return String.format("Monument[id=%d, name='%s', description='%s']", id,
				name,description);
	}


}
